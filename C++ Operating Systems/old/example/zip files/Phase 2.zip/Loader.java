

import java.util.*;
import java.io.*;

/**
* Loader for our OS
*
* @author William Jeff Lett
* @author Kevin DeBrito
*/
public class Loader {
	
	/**
	* Loads the data from disk
	* @param d The disk to load from
	* @return A ArrayList of PCBs in Disk but not RAM.
	*/
	public int load(Disk d, ArrayList<PCB> unReadyQueue) {
		BufferedReader in;
		//ProcessQueue unReadyQueue=null;
		try {
			//unReadyQueue = new ProcessQueue();
			boolean dataStart=false, instStart=false, newProcess=false;
			in = new BufferedReader(new FileReader(Driver.FILE_2_NAME));	
			String line;
			int processIndex, lines=0, offsetWithinPage=-1, page=-1;
			PCB thisPcb=null;
			while ((line = in.readLine()) != null) {
				if(line.contains("JOB")) {
					processIndex=this.startProcess(line);
					thisPcb=unReadyQueue.get(processIndex);									
					instStart=true;
				}
				else if(line.contains("Data")) {
					lines=0;
					this.startData(line,thisPcb);
					dataStart=true;
				}
				else if(line.contains("END")) {
					this.endData(thisPcb,lines);
				} 
				else if(line.length() > 0) {
					if(page==-1 || offsetWithinPage < 0 || offsetWithinPage > (Driver.WORDS_PER-1)) 
					{
						//New Page!!
						page=d.nextPage();
						offsetWithinPage=0;								
					}
					//System.out.println(("Writing:"+line.substring(2,10)+" into:"+page+"+"+offsetWithinPage));
					//int here=next;
					d.write(line.substring(2,10),page,offsetWithinPage);			
					++lines;
					if(instStart) {
						thisPcb.setInstDiskLoc((page*Driver.WORDS_PER+offsetWithinPage));
						instStart=false;	
					}
					if(dataStart) {
						thisPcb.setDataDiskLoc((page*Driver.WORDS_PER+offsetWithinPage));
						dataStart=false;						
					}
					++offsetWithinPage;
				}			
  			}	
			in.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return largestJobSize(unReadyQueue);
	}
	
	
	
	/**
	* Creates a process and parses it's size info into the PCB
	* @param s The line to be put
	* @return The PCB that was created
	*/	
	public int startProcess(String s) {
		PCB tempJob = new PCB();
		int id, size, priority, index;
		String idHex, sizeHex;
		String tempString;
		index = s.indexOf('B');
		
		tempString = s.substring(index+2);
		index = tempString.indexOf(' ');
		idHex = tempString.substring(0,index);
		id = Integer.parseInt(idHex, 16);
		
		tempString = tempString.substring(index+1);
		index= tempString.indexOf(' ');
		sizeHex = tempString.substring(0,index);
		size = Integer.parseInt(sizeHex, 16);
				
		tempString = tempString.substring(index+1);	
		priority = Integer.parseInt(tempString, 16);	
				
		tempJob.setPid(id);
		tempJob.setProcessSize(size);
		tempJob.setPriority(priority);
				
		Driver.newQueue.add(tempJob);	
		return Driver.newQueue.size()-1;	
	}
	
		/**
	* Parses the start of data section
	* @param s The string to process
	* @param p The pcb to enter the info into
	*/
	public static void startData(String s, PCB p) {
		int index, inputSize, outputSize, tempSize;
		String tempString, inputHex, outputHex;
						
		index = s.lastIndexOf("Data")+5;
		tempString = s.substring(index);
		index = tempString.indexOf(' ');
		inputHex = tempString.substring(0,index);
		inputSize = Integer.parseInt(inputHex, 16);
						
		tempString = tempString.substring(index+1);
		index= tempString.indexOf(' ');
		outputHex = tempString.substring(0,index);
		outputSize = Integer.parseInt(outputHex, 16);
		
		tempString = tempString.substring(index+1);	
		tempSize = Integer.parseInt(tempString, 16);			
				
		p.setInputBufferSize(inputSize);
		p.setOutputBufferSize(outputSize);
		p.setTempBufferSize(tempSize);
	}
	
	/**
	* Ends the data section of this process
	* @param p The pcb whose data section we will end
	* @param l The length of the data section
	*/
	public static void endData(PCB p, int l) {
		p.setDataSize(l);
	}
	
	/**
	* Returns the largest job in this queue
	* @return The largest job's size
	*/
	public int largestJobSize(ArrayList<PCB> queue) {
		int maxVal=-1;		
		Iterator<PCB> itr = queue.iterator();
	   while (itr.hasNext()) {
	     PCB element = itr.next();
			if((element.getProcessSize()+element.getDataSize())>maxVal)
				maxVal=(element.getProcessSize()+element.getDataSize());
	   }
	   return maxVal;
	}	
	
}