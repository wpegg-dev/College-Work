import java.util.*;
import java.util.Date; 
/**
* Main Driver for the OS
*
* @author William Jeff Lett
* @author Kevin DeBrito
*/
public class Driver {	

	/* Constants */
	
	/** Page Fault constant */
	public static final String PAGE_FAULT="PAGE_FAULT";
	
	/** How many words per page / frame */
	public static final int WORDS_PER = 4;

	/** How many cpus to run */
	public final static int NUM_CPUS = 1;
	
	/** Scheduling policy, (FIFO,SJF,LOW_PRIORITY or HIGH_PRIORITY) */
   public static SchedulingPolicy schedulingPolicy=SchedulingPolicy.HIGH_PRIORITY;
	
	/** Jeff's Debugging variable.  Set to true for his debugging output. */
	public final static boolean DEBUG = false;
	
	/** Messages can be turned on or off here */
	public final static boolean MESSAGES = true;
	
	/** First input file */
	public final static String FILE_1_NAME = "./include/DataFile1.txt";
	
	/** Second input file */	
	public final static String FILE_2_NAME = "./include/DataFile2.txt";
	
	/** Size of disk */	
	public final static int DISK_SIZE = 2048;

	/** Size of RAM */	
	public final static int RAM_SIZE = 1024;

	/** Number of registers */
	public final static int NUM_REGISTERS = 16;
	
	/** Overall cycle counter */        
 	public static int totalCycleCounter = 0;
 	
 	/** Percentage of ram that is filled total (for ram overall % used) */
 	public static double sumPercent;
 	
	/** Percentage of RAM used overall */ 	
 	public static double totalPercent;
 	
 	/** Variable to hold the largest process size. (To know for cache creation) */
 	public static int largestProcessSize;
 
 	/** Disk instance */	
 	public static Disk disk;
 	
 	/** Ram instance */
 	public static RAM ram;
 	
	/** CPU Array */ 	
 	public static CPU[] cpu;
 	 	
 	/** Loader instance */
 	public static Loader loader;
 	
 	/** ReadyQueue instance */
 	public static ArrayList<PCB> readyQueue;
 	
 	/** newQueue instance */
 	public static ArrayList<PCB> newQueue;
 	
 	/** waitQueue instance */
 	public static ArrayList<PCB> waitQueue;
 	
 	/** terminatedQueue instance */
 	public static ArrayList<PCB> terminatedQueue;
 	
 	/** Queue of processes currently running */
 	public static ArrayList<PCB> runningQueue;

	/** Long Term Scheduler instance */
	public static LongScheduler longTermScheduler;

	/** Short Term Scheduler instance */	
	public static ShortScheduler shortTermScheduler;
	
	/** Current process being run */
	public static PCB[] currentProcess;
   
	/** Tracks the run time of the OS */
	public static long totalRunTime=0;
	
	/** Tracks the cycle time of the OS */
	public static long processRunTime=0;
	   	
	/** Status enum */
	public enum Status {
		/** New process */
		NEW,
		/** Running process */
		RUNNING,
		/** Waiting */
		WAITING,
		/** Ready */
		READY,
		/** Finished process */
		TERMINATED
	};
	
	/** Short-term Scheduling Policy */
	public enum SchedulingPolicy {
		/** First in First out */
		FIFO,
		/** Shortest Job First */
		SJF,
		/** Low Priority Ran First */
		LOW_PRIORITY,
		/** High Priority Ran First */
		HIGH_PRIORITY
	};	

	/**
	* Prints an ArrayList<PCB> for us
	* @param queue The queue of <PCB> to print
	*/
	public static void printQueue(ArrayList<PCB> queue)
	{
		Iterator<PCB> itr = queue.iterator();
	   	while (itr.hasNext()) {
	    	PCB element = itr.next();
			System.out.println("ArrayList Index:"+queue.indexOf(element));	      
	    	element.print();					
		}	
	}
	
	/**
	* Returns the 4 queues info in a string
	* @return A String of queue info
	*/
	public static String queueString() {
		return "newQueueSize:"+newQueue.size()+" readyQueueSize:"+readyQueue.size()+" runningQueueSize:"+runningQueue.size()+" waitQueueSize:"+waitQueue.size()+" terminatedQueueSize:"+terminatedQueue.size();			
	}
	
	/** 
	* Prints the queue info
	*/
	public static void queuePrint() {
		System.out.println(queueString());	
	}

	/**
	 * Print the process ids in each of the queues (for debugging)
	 */
	public static void printQueueIds()
	{
		Iterator<PCB> i=newQueue.iterator();
		System.out.print("newQueue:");
		while(i.hasNext())
		{
			PCB thisProcess=i.next();
			System.out.print(thisProcess.getPid()+",");
		}
		i=readyQueue.iterator();
		System.out.print(" readyQueue:");
		while(i.hasNext())
		{
			PCB thisProcess=i.next();
			System.out.print(thisProcess.getPid()+",");
		}

		i=runningQueue.iterator();
		System.out.print(" runningQueue:");
		while(i.hasNext())
		{
			PCB thisProcess=i.next();
			System.out.print(thisProcess.getPid()+",");
		}
		
		i=waitQueue.iterator();
		System.out.print(" waitQueue:");
		while(i.hasNext())
		{
			PCB thisProcess=i.next();
			System.out.print(thisProcess.getPid()+",");
		}
		
		i=terminatedQueue.iterator();
		System.out.print(" terminatedQueue:");
		while(i.hasNext())
		{
			PCB thisProcess=i.next();
			System.out.print(thisProcess.getPid()+",");
		}
		System.out.println("");
	}
	
	/** 
	* Waits (trying to find this bug)
	* @param i The seconds to wait
	*/
	public static void wait(int i) {
		long t=System.currentTimeMillis(),t2=0;
		while((t2-t)<1000*i) {
			t2=System.currentTimeMillis();	
		}
	}

	/**
	 * Prints the overall process statistics.
	 */
	public static void printOverallStats()
	{
		Iterator<PCB> itr=terminatedQueue.iterator();
        long totalWaitTime=0, totalRunTime=0, totalCompletionTime=0;
        float avgWaitTime=0, avgRunTime=0, avgCompletionTime=0; 
        float avgPageFault=0;
        int totalIoCount=0, totalCyclesRan=0, totalCyclesWaited=0;
        int avgIoCount=0, avgCyclesRan=0, avgCyclesWaited=0,counter=0;
        long totalFaultOverhead=0;
        float avgFaultOverhead=0;
        
        int totalPageFaults=0;
        float avgPF=0,avgIo;
        while(itr.hasNext()) {
        	PCB element=itr.next();
            totalWaitTime+=element.getRealWaitTime();
            totalRunTime+=element.getRealRunTime();
                    totalCompletionTime+=element.getRealWaitTime()+element.getRealRunTime();
                    totalIoCount+=element.getIoCount();
                    totalPageFaults+=element.getPageFaults();
                    totalFaultOverhead+=element.getFaultTime();
                    //totalCyclesRan+=element.getCyclesRan();
                    //totalCyclesWaited+=element.getCyclesWaited();
                    ++counter;
            }
            if(counter!=0) {
                    avgWaitTime=(float)totalWaitTime/(float)counter;
                    avgRunTime=(float)totalRunTime/(float)counter;
                    avgCompletionTime=(float)totalCompletionTime/(float)counter;
                    avgIo=(float)totalIoCount/(float)counter;
                   // avgPageFaults=totalPageFaults/counter;
                    avgPF=(float)totalPageFaults/(float)counter;
                    avgFaultOverhead=(float)totalFaultOverhead/(float)counter;
                    //avgCyclesRan=totalCyclesRan/counter;
                    //avgCyclesWaited=totalCyclesWaited/counter;
                    System.out.println("***** Process Statistics *****");
                    //System.out.println("Average Cycles Ran      : "+avgCyclesRan);
                    System.out.println("Average Running Time    : ("+avgRunTime+"ms)");
                    System.out.println("Average I/O Requests    : "+avgIo);
                    System.out.println("Average Page Faults     : "+avgPF);
                    System.out.println("Average Fault Overhead  : ("+avgFaultOverhead+"ms)");
                    //System.out.println("Average Cycles Waited   : "+avgCyclesWaited);               
                    System.out.println("Average Waiting Time    : ("+avgWaitTime+"ms)");
                    System.out.println("Average Completion Time : ("+avgCompletionTime+"ms)");
            }
           
	}

	/** 
	* Handles a page fault, and loads the missing page into ram
	*/
	public static void pageFault(int i)
	{
		//System.out.println("Faulted pc="+currentProcess[i].getPc());
		if(!currentProcess[i].getPageValidity().get(currentProcess[i].getPc()/Driver.WORDS_PER))
		{
			//Not valid, get it.
			//System.out.println("Getting page#:"+(currentProcess[i].getPc()/Driver.WORDS_PER)+" at:"+currentProcess[i].getPc());
			//System.out.println("read from:"+(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc())+" read:"+disk.read(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc()));
			
			int wroteTo = ram.write2(disk.read(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc()));
			//Rest of the page
			for(int j=1;j<Driver.WORDS_PER;++j)
			{
				//System.out.println("read from:"+(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc()+j)+" read:"+disk.read(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc()+j));
				ram.write2(disk.read(currentProcess[i].getInstDiskLoc()+currentProcess[i].getPc()+j),wroteTo/Driver.WORDS_PER,j);
				currentProcess[i].addFault();
			}
			currentProcess[i].getPageValidity().remove((currentProcess[i].getPc()/Driver.WORDS_PER));
			currentProcess[i].getPageValidity().add((currentProcess[i].getPc()/Driver.WORDS_PER),true);
			currentProcess[i].getPageTable().remove((currentProcess[i].getPc()/Driver.WORDS_PER));
			currentProcess[i].getPageTable().add((currentProcess[i].getPc()/Driver.WORDS_PER),wroteTo);

		}
		currentProcess[i].setStatus(Driver.Status.READY);
		cpu[i].setStatus(Driver.Status.READY);
		waitQueue.remove(currentProcess[i]);
		readyQueue.add(0,currentProcess[i]);
		//System.out.print("Just moved process from waitQueue to readyQueue in driver pageFault:");
	//	Driver.printQueueIds();

		
		//currentProcess[i].print();
		//System.out.println(ram.toWideString());
	}

	public static void main(String[] args) {
		
		readyQueue 		 = new ArrayList<PCB>();
		runningQueue	 = new ArrayList<PCB>();
		newQueue 		 = new ArrayList<PCB>();
		waitQueue 		 = new ArrayList<PCB>();
		terminatedQueue  = new ArrayList<PCB>();
		
		
		currentProcess = new PCB[NUM_CPUS];		
		cpu=new CPU[NUM_CPUS];		
		
		long programStart=System.currentTimeMillis();
		long tmp;
		long processStart[]=new long[NUM_CPUS];
		for(int i=0;i<NUM_CPUS;++i)
			processStart[i]=0;
				
		int startingCycleCounter[]=new int[NUM_CPUS];
		for(int i=0;i<NUM_CPUS;++i)
			startingCycleCounter[i]=0;
		
		// Create the Disk
		tmp = System.currentTimeMillis();
		if(MESSAGES) 
			System.out.print("Instantiating Disk...");
		disk = new Disk();		
		if(disk!=null && MESSAGES) 
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
		else if(MESSAGES)
			System.out.println("Failure!");			
		
		// Load
		tmp = System.currentTimeMillis();
		if(MESSAGES) 	
			System.out.print("Loading processes into Disk...");
		loader = new Loader();
		largestProcessSize=loader.load(disk,newQueue);
		if(MESSAGES)
			if(loader!=null)
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
			else 
				System.out.println("Failure!");	
		


		
		
		// Create the Framed RAM
		tmp = System.currentTimeMillis();
		if(MESSAGES)
			System.out.print("Creating Framed RAM...");
		ram=new RAM();		
		if(MESSAGES)
			if(ram!=null)
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
			else
				System.out.println("Failure!");					
						
		// Create the Long Term Scheduler
		tmp = System.currentTimeMillis();		
		if(MESSAGES) 	
			System.out.print("Creating Long Term Scheduler...");				
   	   	longTermScheduler = new LongScheduler(ram,disk);
		if(MESSAGES)
			if(longTermScheduler!=null)
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
			else 
				System.out.println("Failure!");


		

 		// Create the Short Term Scheduler
		tmp = System.currentTimeMillis();
		if(MESSAGES) 	
			System.out.print("Creating Short Term Scheduler...");		
  	    shortTermScheduler = new ShortScheduler(disk,ram);
		if(MESSAGES)
			if(shortTermScheduler!=null)
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
			else 
				System.out.println("Failure!");			
      
	    // Create the CPUs
		tmp = System.currentTimeMillis();
		if(MESSAGES) 	
			System.out.print("Creating "+NUM_CPUS+" CPUs...");
		for(int i=0;i<NUM_CPUS;++i)
			cpu[i]=new CPU(largestProcessSize+1);
		if(MESSAGES)
			if(cpu!=null)
				System.out.println("Success! ("+(System.currentTimeMillis()-tmp)+"ms)");
			else 
				System.out.println("Failure!");			

		
		int processesFinished = 0;
		longTermScheduler.start();
		
		System.out.println("Program Setup Time: ("+(System.currentTimeMillis()-programStart)+"ms)");
		programStart=System.currentTimeMillis();
	
		//Start looping through processes
		do {				
			//Handle Dispatching for all the cpus
			for(int i=0;i<NUM_CPUS;++i) {
				if(cpu[i].status==Driver.Status.WAITING)
				{
					
					//currentProcess[i].setRealRunTime(currentProcess[i].getRealRunTime()+System.currentTimeMillis()-processStart[i]);	
					//currentProcess[i].setCyclesRan(currentProcess[i].getCyclesRan()+totalCycleCounter-startingCycleCounter[i]);									
					
					waitQueue.add(currentProcess[i]);
					runningQueue.remove(currentProcess[i]);	
					currentProcess[i].addRunTime(System.currentTimeMillis()-currentProcess[i].getLastStateSwitch());
					cpu[i].setStatus(Driver.Status.READY);
										
				}
				if(cpu[i].status==Driver.Status.TERMINATED || cpu[i].status==Driver.Status.READY || cpu[i].status==Driver.Status.NEW) {	
					if(readyQueue.size() > 0) {
						//Dispatch
						if(currentProcess[i]!=null)
						{
							//System.out.println("DISPATCHING TO BE DONE WITH:");
							//currentProcess[i].print();
						}
						currentProcess[i]=shortTermScheduler.dispatch(readyQueue);	
						
						startingCycleCounter[i]=totalCycleCounter;
						processStart[i]=System.currentTimeMillis();										
						if(currentProcess[i]!=null) {	
							
						
							readyQueue.remove(currentProcess[i]);
							if(!runningQueue.contains(currentProcess[i]))
							{		
								runningQueue.add(currentProcess[i]);
								currentProcess[i].addWaitTime(System.currentTimeMillis()-programStart);
							}
							//System.out.print("Just moved process from readyQueue to runningQueue in Driver:");
							//Driver.printQueueIds();

							//Start the process	
							currentProcess[i].setStatus(Status.RUNNING);	
							//currentProcess[i].setPc(currentProcess[i].getInstMemLoc());
	
							//Context Switch from ram to cpu
							shortTermScheduler.restoreState(cpu[i],currentProcess[i],ram);
							cpu[i].setStatus(Driver.Status.RUNNING);
							//cpu[i].setPc(currentProcess[i].getPc());
						}
						else
							System.out.println("Dispatched null");		
					}
				} 
				
			}
			for(int i=0;i<NUM_CPUS;++i) {
				//Run the cpus
				//System.out.println("i="+i);
				//System.out.println("terminatedQueue.size()="+terminatedQueue.size());
				if(currentProcess[i]!=null) {
					String tmp2=cpu[i].fetch(currentProcess[i]);	
					if(tmp2.equals(PAGE_FAULT))
					{
						 
						shortTermScheduler.saveState(cpu[i],currentProcess[i],ram);
					
							//System.out.println("page fault");
							//cpu[i].print();				
						//currentProcess[i].pageFault(disk);
						shortTermScheduler.pageFault(currentProcess[i],cpu[i]);			
						
					}
					else
					{	
						if(cpu[i].getStatus()!=Status.TERMINATED) {
							cpu[i].execute(cpu[i].decode(tmp2));
						}
							//cpu[i].print();
						//currentProcess[i].print();
						//System.out.println(currentProcess[i].pageTableValuesToString());
						//check for end of process and process stats if so			
						if(cpu[i].getStatus()==Status.TERMINATED) {
							if(!terminatedQueue.contains(currentProcess[i])) {
								
								
								//currentProcess[i].print();
								//System.out.println(ram.toWideString());
								shortTermScheduler.saveState(cpu[i],currentProcess[i],ram);
   	      			   			//cpu[i].print();

									String out = "Process "+currentProcess[i].getPid()+" Finished, OutputBuffer=";
					            for(int j=0;j<currentProcess[i].getOutputBufferSize();++j) {
	   	      			   			if(j!=0)
	   	      			   				{out+=",";}  
	   	         	  				//Integer.toString(Integer.parseInt(ram.read((i+currentProcess.getDataMemLoc()+currentProcess.getInputBufferSize())),16));                               
	   	      			   			out+=Integer.toString(Integer.parseInt(cpu[i].getCache()[j+currentProcess[i].getProcessSize()+currentProcess[i].getInputBufferSize()],16));                                   
	   	         				}
	   	         				System.out.println(out);						
							
	
								//System.out.println("ending and calcumalating process:"+currentProcess[i].getPid());
	
								
								//System.out.println(ram.toWideString());
								//currentProcess[i].setCyclesRan(totalCycleCounter-startingCycleCounter[i]);
								//currentProcess[i].setCyclesWaited(startingCycleCounter[i]);
								//currentProcess[i].setRealRunTime((System.currentTimeMillis()-processStart[i]));
								//currentProcess[i].setRealWaitTime((processStart[i]-programStart));
								
								longTermScheduler.end(currentProcess[i],cpu[i]);							
								shortTermScheduler.saveState(cpu[i],currentProcess[i],ram);
								ram.freeProcess(currentProcess[i]);
								terminatedQueue.add(currentProcess[i]);
								runningQueue.remove(currentProcess[i]);
								currentProcess[i].addRunTime(System.currentTimeMillis()-currentProcess[i].getLastStateSwitch());
								//System.out.print("Just moved process from runningQueue to terminatedQueue in Driver:");
								//Driver.printQueueIds();
								++processesFinished;
							}										
						}
					}
				}
				else
					System.out.println("null process");					
				
			}
	//	System.out.println(ram.toWideString());
			//cpu[0].printRegisters();	
			//currentProcess[0].printRegisters();
			//cpu[0].print();
			//System.out.println(disk.toWideString());
			//System.out.println(ram.toWideString());
			++totalCycleCounter;
			ram.saveStats();
			
			
			if((readyQueue.size()) <= 0 && newQueue.size() > 0) {
				//System.out.println("Erasing RAM for more processes");
				//System.out.println(ram.toWideString());			
				//ram.erase();			
				//longTermScheduler.start();
			}		
			
			//processesFinished++;	
		//cpu[0].print();
		//currentProcess[0].print();
		//System.out.println(ram.toWideString());	
			//System.out.println("Terminated Processes:"+terminatedQueue.size());
			//queuePrint();
			//printQueue(runningQueue);
		} while((readyQueue.size() > 0 || newQueue.size() > 0 || runningQueue.size() > 0) && processesFinished<30);// && totalCycleCounter<300);// && processesFinished < 8);
		//System.out.println(disk.toWideString());
		
		//terminatedQueue.printPretty(terminatedQueue);	
		//ProcessQueue.printStats(terminatedQueue);
		int totalCacheUsed=0; 
		for(int i=0;i<NUM_CPUS;++i) {			
			//System.out.print("CPU["+i+"] ");	
			totalCacheUsed+=cpu[i].getCacheInfo(totalCycleCounter);
	
		}
		//System.out.println("Average Cache Used: "+(totalCacheUsed/NUM_CPUS)+"%");
	//	System.out.println(ram.toWideString());
	//System.out.println(disk.toWideString());
		//ram.printStats(totalCycleCounter);
		Iterator<PCB> i = terminatedQueue.iterator();
		while(i.hasNext())
		{
			PCB p = i.next();
			p.printStats();
			System.out.println("");
		}
		printOverallStats();
		ram.erase();
		//disk.printWide();
		disk.erase();
		
	}
}