
import java.util.*;

/**
* Short Term Scheduler for our OS
*
* @author William Jeff Lett
* @author Kevin DeBrito
*/
public class ShortScheduler {
	public static Disk disk;
	public static RAM ram;

	public static final boolean DEBUG=false;
	
	ShortScheduler(Disk d, RAM r)
	{
		ram=r;
		disk=d;
	}
	
		/**
	* Formats a hex string for RAM
	* @param s The hex string to format
	* @return The formatted hex string
	*/
	public static String hexFormat(String s) {
		if(s!=null && s!="") {
			s=s.toUpperCase();
			for(int i=0+s.length();i<8;++i)
				s="0"+s;
			return s;
		}
		return "00000000";
	}


	/** 
	* Handles a page fault, and loads the missing page into ram
	*/	
	public static void pageFault(PCB currentProcess, CPU cpu)
	{
		//System.out.println("Faulted pc="+currentProcess.getPc());
		if(!currentProcess.getPageValidity().get(currentProcess.getPc()/Driver.WORDS_PER))
		{
			//Not valid, get it.
			//System.out.println("Getting page#:"+(currentProcess.getPc()/Driver.WORDS_PER)+" at:"+currentProcess.getPc());
			//System.out.println("read from:"+(currentProcess.getInstDiskLoc()+currentProcess.getPc())+" read:"+disk.read(currentProcess.getInstDiskLoc()+currentProcess.getPc()));
			
			int wroteTo = ram.write2(hexFormat(disk.read(currentProcess.getInstDiskLoc()+currentProcess.getPc())));
			//Rest of the page
			for(int j=1;j<Driver.WORDS_PER;++j)
			{
				//System.out.println("read from:"+(currentProcess.getInstDiskLoc()+currentProcess.getPc()+j)+" read:"+disk.read(currentProcess.getInstDiskLoc()+currentProcess.getPc()+j));
				ram.write2(hexFormat(disk.read(currentProcess.getInstDiskLoc()+currentProcess.getPc()+j)),wroteTo/Driver.WORDS_PER,j);	
			}
			currentProcess.getPageValidity().remove((currentProcess.getPc()/Driver.WORDS_PER));
			currentProcess.getPageValidity().add((currentProcess.getPc()/Driver.WORDS_PER),true);
			currentProcess.getPageTable().remove((currentProcess.getPc()/Driver.WORDS_PER));
			currentProcess.getPageTable().add((currentProcess.getPc()/Driver.WORDS_PER),wroteTo);

		}
		currentProcess.setStatus(Driver.Status.READY);
		cpu.setStatus(Driver.Status.READY);
		Driver.waitQueue.remove(currentProcess);
		Driver.readyQueue.add(0,currentProcess);
	//	System.out.print("Just moved process from waitQueue to readyQueue in short scheduler pagefault:");
	//	Driver.printQueueIds();

		
		//currentProcess[i].print();
		//System.out.println(ram.toWideString());
	}
	
	
	/**
	* Handles a data fault
	*/
	public static void dataFault(PCB currentProcess, CPU cpu, int page)
	{
		long time=System.currentTimeMillis();
		//System.out.println("in dataFault");
		//cpu.print();
		cpu.status=Driver.Status.WAITING;
		currentProcess.addFault();
		saveState(cpu,currentProcess,ram);
	
		restoreState(cpu,currentProcess,ram);
		
		if(DEBUG)
			{System.out.println("DATAAAAAAAAAAAAAAAAAAA ******************** Page="+page);}
		//System.out.println("AFTER SAVE/RESTORE!!!!");
		//cpu.print();
		if(!currentProcess.getPageValidity().get(page))
		{
			//Not valid, get it.
			//System.out.println("Getting page#:"+(page));
			//System.out.println("ERRRRRRRRRRRRRRRR read from:"+(page*Driver.WORDS_PER)+" read:"+disk.read((currentProcess.getInstDiskLoc()+page*Driver.WORDS_PER)));
			//System.out.println("instMemLoc:"+currentProcess.getInstMemLoc() + " instDiskLoc:"+currentProcess.getInstDiskLoc());
			//System.out.println("23="+disk.read(23));
			//System.out.println("0="+disk.read(0));
			int wroteTo = ram.write2(hexFormat(disk.read(currentProcess.getInstDiskLoc()+page*Driver.WORDS_PER))	);
			//System.out.println("Wrote to "+wroteTo+" read from "+(currentProcess.getInstDiskLoc()+page*Driver.WORDS_PER)+" and read:"+hexFormat(disk.read(currentProcess.getInstDiskLoc()+page*Driver.WORDS_PER)));
			//Rest of the page
			for(int j=1;j<Driver.WORDS_PER;++j)
			{
				//System.out.println("read from:"+(page*Driver.WORDS_PER+j)+" read:"+disk.read(page*Driver.WORDS_PER+j)+" page="+page+" wroteTo="+wroteTo);
				ram.write2(hexFormat(disk.read(currentProcess.getInstDiskLoc()+page*Driver.WORDS_PER+j)),wroteTo/Driver.WORDS_PER,j);	
			}
			currentProcess.getPageValidity().remove(page);
			currentProcess.getPageValidity().add(page,true);
			currentProcess.getPageTable().remove(page);
			currentProcess.getPageTable().add(page,wroteTo);

		}
		currentProcess.setStatus(Driver.Status.READY);
		cpu.setStatus(Driver.Status.READY);
		
		Driver.waitQueue.remove(currentProcess);
		Driver.readyQueue.add(0,currentProcess);
		
		//System.out.println("AFTER READ");
		//currentProcess.print();
	
		//currentProcess.print();
		//cpu.print();
		//System.out.println(ram.toWideString());
		//System.out.println("left dataFault");
	//	System.out.println("Adding faulttime="+(System.currentTimeMillis()-time)+" to process:"+currentProcess.getPid());
		currentProcess.addFaultTime(System.currentTimeMillis()-time);
	}


	/**
	* Restore state
	* @param c The cpu to restore
	* @param p The process to restore from
	* @param r The ram to be read from
	*/
	public static void restoreState(CPU c, PCB p, RAM r) {
		//System.out.println("Restoring p:");		
		//p.print();
		//System.out.println("********** restoring state ****** CPU:"+c.toString());
		//p.print();	
		//System.out.println("cache size:"+c.getCacheSize()+" p.size():"+p.getSize());
		int start=p.getInstMemLoc(), end=start+p.getSize();
		//System.out.println("pc start"+start+", pc end:"+end);
		for(int i=0;i<c.getCacheSize();++i) {
			if(i<end-start && p.getPageValidity().get(i/Driver.WORDS_PER)) {
				//System.out.println("i="+i+" processSize="+p.getProcessSize()+" cacheSize="+c.getCacheSize());
				//System.out.println("restoring validity="+p.getPageValidity().get(i/Driver.WORDS_PER));
				//System.out.println("read"+r.read(start+i));
				//System.out.println("pageTable="+p.getPageTable().get(i/Driver.WORDS_PER)+" offset:"+(i%Driver.WORDS_PER)+" start+i:"+(start+i));
				//System.out.println("writing="+r.read((p.getPageTable().get(i/Driver.WORDS_PER)+(i%Driver.WORDS_PER)))+" i="+i);
//				System.out.println
				c.getCache()[i]=hexFormat(r.read((p.getPageTable().get(i/Driver.WORDS_PER)+(i%Driver.WORDS_PER))));	
			}
			else {
				c.getCache()[i]="00000000";	
			}
		}		
		c.setRegisters(p.getRegisters());
		c.setPc(p.getPc());
		//c.setPc(p.getInstMemLoc());
		//c.print();
//		System.out.println("cpu-pc:"+c.getPc()+" "+p.getInstMemLoc());
//		System.out.println(c.toString());
		//System.out.println(p.toString());		
		//System.out.println("********** restoring state ****** CPU:"+c.toString());	
		//System.out.println("Done restoring p:");
		//p.print();
	}
	
	/**
	* Save state
	* @param c The cpu to be saved
	* @param p The process to be saved to 
	* @param r The ram to be read to
	*/
	public static void saveState(CPU c, PCB p, RAM r) {
		//System.out.println("INSIDE SAVE:");		
		//p.print();
		//c.print();
		//System.out.println("Saving"+p.getPid()+"\n\n\n\n\n");
		int start=p.getInstMemLoc(), end=start+p.getSize();
		for(int i=0;i<end-start;++i) {
			//Only update the modified stuff
			//System.out.println("i/Driver.WORDS_PER="+i/Driver.WORDS_PER);
			//System.out.println("p.getPageValidity().get(i/Driver.WORDS_PER)="+p.getPageValidity().get(i/Driver.WORDS_PER));
			
			//System.out.println("i="+i+" modified:"+c.getCacheModified()[i]+" valid:"+p.getPageValidity().get(i/Driver.WORDS_PER));
			if(c.getCacheModified()[i]==true && p.getPageValidity().get(i/Driver.WORDS_PER))		
			{
				int page=p.getPageTable().get(i/Driver.WORDS_PER);
				int offset=i%Driver.WORDS_PER;
				//System.out.println("page="+page+" offset="+offset+" i="+i);
				r.write(c.getCache()[i],page+offset);	
				//System.out.println("Saving line i="+i+"="+c.getCache()[i]+" to:"+start+i);
				//System.out.println(ram.toWideString());
			}
			else 
			{
			 	//System.out.println("Not Printing i="+i);
			}
		}		
		//System.out.println(r.toWideString());
		p.setRegisters(c.getRegisters());
		p.setPc(c.getPc());
		//c.clearCache();
		//System.out.println("LEAVING SAVE");
		//p.print();
	}

	/** 
	* Dispatches the next process according to the short term scheduling policy
	* @param p The ready queue to get the process from
	* @return The PCB of the process to run next
	*/
	public static PCB dispatch(ArrayList<PCB> p) {
		//System.out.println("p.size():"+p.size());
		if(p.size() > 0) {
			switch(Driver.schedulingPolicy) {
				case FIFO:
					//System.out.println("FIFO Dispatching");// p.size="+p.getQueue().size());	
					return p.get(0);		
				case SJF:
					int i=0,shortestIndex=-1,shortestLength=Integer.MAX_VALUE;
					Iterator<PCB> itr = p.iterator();
		   			while (itr.hasNext()) {
		     			PCB element = itr.next();
						if(element.getProcessSize() < shortestLength) {
							shortestLength=element.getProcessSize();
								shortestIndex=i;	
						}				
	      			++i;
	   	 			}				
					//System.out.println("SJF Dispatching Size:"+shortestLength);
					return p.get(shortestIndex);
				case LOW_PRIORITY:
					int j=0,lowestIndex=-1,lowestPriority=Integer.MAX_VALUE;					
					Iterator<PCB> itr2 = p.iterator();
		   			while (itr2.hasNext()) {
		     			PCB element = itr2.next();
						if(element.getPriority() < lowestPriority) {
							lowestPriority=element.getPriority();
								lowestIndex=j;	
						}				
	      			++j;
	    			}		
										
					//System.out.println("Low Priority Dispatching Priority:"+lowestPriority);
					return p.get(lowestIndex);
					
				case HIGH_PRIORITY:
					int k=0,highestIndex=-1,highestPriority=Integer.MIN_VALUE;					
					Iterator<PCB> itr3 = p.iterator();
	   				while (itr3.hasNext()) {
	   	   		PCB element = itr3.next();
						if(element.getPriority() > highestPriority) {
							highestPriority=element.getPriority();
							highestIndex=k;	
						}				
	     				++k;
	   				}		
									
					//System.out.println("High Priority Dispatching Priority:"+highestPriority);
					return p.get(highestIndex);
			}					
		return p.get(0);		

		}	
		return null;
	}	
}		
