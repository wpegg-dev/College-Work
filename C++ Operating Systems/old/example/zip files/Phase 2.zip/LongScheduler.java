import java.util.ArrayList;

/**
* Long Scheduler for our OS
* 
* @author William Jeff Lett
* @author Kevin DeBrito
*/
public class LongScheduler 
{
	/** Debugging constant for this class */
	public static final boolean DEBUG=false;	
	
	/** Ram */	
	RAM ram;
	
	/** Disk */
	Disk disk;
	
	/** Our current process's index */
	private int current_process;
	


	/** Our current Process */
	PCB process;

	///percentage of ram being used
	double percentRAM = 0;

	///Default Constructor. starts the ready queue and current process value
	public LongScheduler ()
	{
		current_process=-1;
		ram=null;
		disk=null;			
	}
	
	/** 
	* Constructor with ram and disk
	* @param r The ram to use
	* @param d The disk to use
	*/
	public LongScheduler(RAM r, Disk d) {
		current_process=-1;			
		ram=r;
		disk=d;	
	}	
	
	/**
	* Iterates through the newQueue and places processes into RAM and into the readyqueue
	*/
	public void start() {
		if (!loadProcess())
		{
			return;
		}
		int processes = Driver.newQueue.size();
		for(current_process=1;current_process<=processes;++current_process) {	
//			System.out.println("Current_Process_Index="+current_process+" and max="+processes);
			
			process = Driver.newQueue.get(0);
						
			if(DEBUG)
			{
				System.out.println("Instructions size="+process.getProcessSize());
				System.out.println("Data Size="+process.getDataSize());
			}
			
			
			//Check to see if there's enough room left in ram.  return if not.
			if(((Driver.WORDS_PER*2*2)>ram.freeFrames())) {
				
				System.out.println("No more room in RAM. Only "+ram.freeFrames());
				return;
			}
			
			
			
			
			
			int ramDataLoc=0, ramInstLoc=0, page=-1, offset=-1, pageCount=0;
			
			int INITIAL_INSTRUCTION_PAGES=4;
			int INITIAL_DATA_PAGES=4;
		
			

			
			
			//Input initial instructions (4 pages)
			int currentPage=0;
			for(int here=process.getInstDiskLoc();currentPage<INITIAL_INSTRUCTION_PAGES;++currentPage)
			{
				//System.out.println("outer loop = "+process.getProcessSize()/Driver.WORDS_PER);
				
				for(int currentOffset=0;currentOffset<Driver.WORDS_PER;++currentOffset,++here)
				{
					if(currentPage==0 && currentOffset==0)
					{
						process.setInstMemLoc(ram.write2(disk.read(here)));				
						process.setPc(0);
						process.getPageTable().add(process.getPageTable().size(),(process.getInstMemLoc()));
						process.getPageValidity().add(process.getPageValidity().size(),true);
					}
					else if(currentOffset==0)
					{
						int justWroteTo=ram.write2(disk.read(here));
						process.getPageTable().add(process.getPageTable().size(),(justWroteTo));
						process.getPageValidity().add(process.getPageValidity().size(),true);
					}
					else
					{	
						ram.write2(disk.read(here),process.getInstMemLoc()/Driver.WORDS_PER+currentPage,currentOffset);
					}	
					//System.out.println("here="+here+" currentPage="+currentPage+" currentOffset="+currentOffset+" writing="+disk.read(here));				
				}	
			}	
			for(;currentPage<Driver.largestProcessSize/Driver.WORDS_PER;++currentPage)
			{
				process.getPageTable().add(process.getPageTable().size(),-1);
				process.getPageValidity().add(process.getPageValidity().size(),false);		
			}
		///System.out.println("Largest Process Size:"+Driver.largestProcessSize);
		//	process.print();
			//System.out.println(ram.toWideString());
			/*
			//Loop through each line of the process instructions
			for(int here=process.getInstDiskLoc(),i=process.getProcessSize();i>0;--i,++here) {
				//System.out.println("new line, here="+here+" i="+i+" processSize="+process.getProcessSize());
				boolean needNewFrame=false;
				
				if(offset > 3 || offset < 0) 
				{	
					offset=0;			
					needNewFrame=true;
				}		
					
				//first page			
				if(page==-1) 
				{
			
					process.setInstMemLoc(ram.write2(disk.read(here)));
					process.setPc(process.getInstMemLoc());
					if(DEBUG)
					{					
						System.out.println("Just set process instMemLoc() to "+process.getInstMemLoc());										
					}					
					page=(process.getInstMemLoc()/Driver.WORDS_PER);				
					needNewFrame=false;		
					if(DEBUG)					
					{				
						System.out.println("Inst Page:"+page+" Starts at "+page*Driver.WORDS_PER);
					}					
					process.getPageTable().add(process.getPageTable().size(),(page*Driver.WORDS_PER));
					process.getPageValidity().add(process.getPageValidity().size(),true);
					pageCount++;
				}
				//new page
				else if(needNewFrame)
				{
					//System.out.println("new frame needed");
					if(pageCount<4)
					{
						int beginning=ram.write2(disk.read(here));
						//System.out.println("Inst beg="+process.getInstMemLoc());
						page=(beginning/Driver.WORDS_PER);				
						needNewFrame=false;		
						if(DEBUG)
						{					
							System.out.println("Inst Page:"+page+" Starts at "+page*Driver.WORDS_PER);
						}					
						//System.out.println("Adding frame# (also pagetable size):"+process.getPageTable().size());
						process.getPageTable().add(process.getPageTable().size(),(page*Driver.WORDS_PER));
						process.getPageValidity().add(process.getPageValidity().size(),true);
					}
					else
					{
						process.getPageTable().add(process.getPageTable().size(),0);
						process.getPageValidity().add(process.getPageValidity().size(),false);	
						if(DEBUG)
							{System.out.println("Skipping writing an instruction pageCount="+pageCount+" offset="+offset);}
					}	
					pageCount++;					
				}
				else
				{	
					if(pageCount<5)
						{ram.write2(disk.read(here),page,offset);	}
					else
					{
							if(DEBUG) {System.out.println("Skipping writing an instruction pageCount="+pageCount+" offset="+offset);}
					}
				}				
				++offset;		
			} 
			
			
			*/
			
			
			/*
			pageCount=0;
			page=-1;
			for(int here=process.getDataDiskLoc(),i=process.getDataSize();i>0;--i,++here) {
				//System.out.println("new line, here="+here+" i="+i+" processSize="+process.getData	Size());
				boolean needNewFrame=false;				
				if(offset > 3 || offset < 0) 
				{	
					offset=0;			
					needNewFrame=true;			
				}	

				if(page==-1) {
					offset=0;
					process.setDataMemLoc(ram.write2(disk.read(here)));	
					if(DEBUG) {				
						System.out.println("Just set DataMemLoc() to "+process.getDataMemLoc()+" read from:"+here+" read:"+disk.read(here));
					}					
					page=(process.getDataMemLoc()/Driver.WORDS_PER);
					needNewFrame=false;
					if(DEBUG)
					{
						System.out.println("Process:"+current_process+" Data Page Starts at "+page*Driver.WORDS_PER);
					}
					process.getPageTable().add(process.getPageTable().size(),(page*Driver.WORDS_PER));
					process.getPageValidity().add(process.getPageValidity().size(),true);
					++pageCount;
				}	
				else if(needNewFrame)
				{

					if(pageCount<4)
					{
						int beginning=ram.write2(disk.read(here));
						page=(beginning/Driver.WORDS_PER);
						needNewFrame=false;
						if(DEBUG)
						{
							System.out.println("Process:"+current_process+" Data Page Starts at "+page*Driver.WORDS_PER);
						}
						process.getPageTable().add(process.getPageTable().size(),(page*Driver.WORDS_PER));
						process.getPageValidity().add(process.getPageValidity().size(),true);
					}
					else 
					{
						process.getPageTable().add(process.getPageTable().size(),0);
						process.getPageValidity().add(process.getPageValidity().size(),false);		
					}
					++pageCount;				
				} 			
				else	
					if(pageCount<4)
						{ram.write2(disk.read(here),page,offset);}
				++offset;			
			}
			*/	
			//	process.print();		
			process.setStatus(Driver.Status.READY);
			Driver.newQueue.remove(process);
			Driver.readyQueue.add(process);
		//	System.out.print("Just moved process from newqueue to readyqueue in long scheduler:");
		//	Driver.printQueueIds();
		}
		//System.out.println(ram.toWideString());
	}
	
	/**
	* Writes a process's cache from RAM back into the disk
	*/
	public void end(PCB currentProcess, CPU c) {	
		for(int here=currentProcess.getProcessSize(),there=currentProcess.getDataDiskLoc(),i=currentProcess.getDataSize();i>0;--i,++here,++there) {
			disk.write(c.getCache()[here],there);	
		}
	}

	/**
	* This function returns whether there is processes left to load
	* @return This returns true is there are processes to load
	*/ 
	public boolean loadProcess() 
   {
   	if(Driver.newQueue.size() > 0)
   		return true;
   	else
   		return false;
   }
 
}
        

