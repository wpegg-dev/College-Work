/**
* RAM broken up into Frames emulator
*
* @author William Jeff Lett
* @author Kevin DeBrito
*/

import java.util.*;

public class RAM
{
	/** The static instance of RAM */
	private static String [] ram;
		
	/** The size of RAM */
	private static int size;
	
	/** The total RAM used (for stats) */
	private static int totalRamUsed;
		
	/** The number of frames */
	private static int numFrames;
	
	/** Empty Ram Array */
	private static boolean[] isFull;
	
	
	
	/**
	* Default constructor
	*/
	public RAM()
	{
		ram=new String[Driver.RAM_SIZE];
		size=Driver.RAM_SIZE;
		totalRamUsed=0;
		numFrames=(Driver.RAM_SIZE/Driver.WORDS_PER);
		isFull = new boolean[numFrames];
		for(int i=0;i<numFrames;++i) {
			isFull[i]=false;
		}
	}
		
	/**
	* Constructor builds RAM of a certain size
	* @param s The size of the RAM to be created
	*/
	public RAM(int s)
	{
		ram=new String[s];
		size=ram.length;
		totalRamUsed=0;
		numFrames=(Driver.RAM_SIZE/Driver.WORDS_PER);
		isFull = new boolean[numFrames];
		for(int i=0;i<numFrames;++i) {
			isFull[i]=false;
		}
	}
	
	/** 
	* Returns the next available frame to write into ram
	* @return The next available frame to write into ram
	*/
	public int nextFrame() 
	{
		for(int i=0;i<numFrames;++i) 
		{
			if(isFull[i]==false)
			{
				return i;
			}
		}
		return -1;
	}	
	
	/**
	* Saves the ram info (for stats)
	*/
	public static void saveStats() {
		totalRamUsed+=((framesUsed()*100)/size);	
	}	
	
	/** 
	* Prints the RAM info (for stats)
	* The number of cycles that have been run
	*/
	public static void printStats(int totalCycleCounter) {
		System.out.println("Average RAM Used: "+(totalRamUsed/totalCycleCounter)+"%");
	}
	
	/**
	* Returns the size
	* @return The size of this RAM
	*/
	public static int size()
	{
		return size; 
	}	
	
	public static int frames()
	{
		return numFrames;
	}
		
	
	/**
	* Returns whether the RAM is empty or not
	* @return Whether the RAM is empty or not
	*/
	private static boolean empty() 
	{ 
		for(int i=0;i<numFrames;++i) {
			if(isFull[i]==true) {
				return false;	
			}
		}
		return true;	
	}
	
	/** 
	* Returns whether the RAM is full or not
	* @return Whether the RAM is full or not
	*/
	public static boolean full() {
		//return nextFreeWord==Driver.RAM_SIZE;	
		for(int i=0;i<numFrames;++i) {
			if(isFull[i]==false) {
				return true;	
			}	
		}
		return false;
	}
	
	
	/**
	 * Frees a process's memory up
	 * @param p The process to be freed 
	 */
	public void freeProcess(PCB p)
	{
		//System.out.println("Freeing up process:"+p.getPid());
		for(Iterator i=p.getPageTable().iterator();i.hasNext();)
		{
			int tmp=((Integer)i.next()).intValue();
			if(tmp!=-1)
			{
				//System.out.println("Page i="+tmp);
				isFull[tmp/Driver.WORDS_PER]=false;
				for(int j=0;j<Driver.WORDS_PER;++j)
				{
					//System.out.println("Gonna erase:"+(tmp+j));
					//isFull[tmp+j]=false;
					//this.write("00000000",(tmp+j));
				}
			}
		}
		
	}
	
	/**
	* Returns the used frames in RAM
	* @return The used frames in RAM
	*/
	public static int framesUsed() {
		return numFrames-freeFrames();
	}	
	
	/**
	* Returns the frames left in RAM
	* @return The frames left in RAM
	*/
	public static int freeFrames() {
		int free=numFrames;
		for(int i=0;i<numFrames;++i) {
			if(isFull[i]==true)
			{
				--free;
			}	
		}	
		return free;
	}	
	
	/**
	* Converts the RAM to a string for debugging
	* @return A string representation of this RAM
	*/
	public String toString()
   {
   	String temp = "Memory Dump:\n";          
      for(int i = 0; i < ram.length; i++)
      {
      	if(ram[i]!=null) {
		      temp += ram[i];
				if(i%8==7)
					temp+="\n";		   
		   }
      }            
      return temp;
   }
   
	/**
	* Returns a string value of a certain part of the RAM
	* @param b Where to begin the string
	* @param e Where the end the string
	* @return A string representation of part of the RAM	
	*/
	public String toString(int b, int e) {
		String r = "RAM Contents "+b+"-"+e+":\n";
		for(int i=b;i<e;++i) {
			int width=12;
			if(ram[i]==null)
				r+="00000000";
			else					
				r+=ram[i];	
			if(i%width!=width-1)
				r+=",";
			if(i%width==width-1)
				r+=":"+i+"\n";	
		}
		return r;
	}   
   
	/**
	* Returns a wider representation of the ram (to see it all on 1 screen for debugging)
	* @return A string value of this ram
	*/
	public String toWideString() {
		String r="Ram["+size+"]:\n";
		for(int i=0;i<ram.length;++i) {
			int width=12;
			if(ram[i]==null)
				r+="00000000";
			else					
				r+=ram[i];	
			if(i%width!=width-1)
				r+=",";
			if(i%width==width-1)
				r+=":"+i+"\n";	
		}
		return r;
	}  
   	
   /**
	* Erases the contents of this ram
	*/
	public static void erase() {
		for(int i=0;i<ram.length;++i) {
			ram[i]="00000000";	
		}	
		for(int i=0;i<numFrames;++i) {
			isFull[i]=false;	
		}
	}	
   
	/**
	* Formats a hex string for RAM
	* @param s The hex string to format
	* @return The formatted hex string
	*/
	public static String hexFormat(String s) {
		if(s!=null && s!="") {
			s=s.toUpperCase();
			for(int i=0+s.length();i<8;++i)
				s="0"+s;
			return s;
		}
		return "00000000";
	}
   
   
   /**
   * Reads from RAM the DMA way
   * @param b The base address of this process
   * @param o The offset of this read
   */
   public static String read(int b, int o) {
   	if(b+o>=0 && b+o<Driver.RAM_SIZE) {
   		return ram[b+0];
   	}
   	else {
   		System.out.println("RAM Read Error @ Location:"+(b+0));
   		return "";	
   	}
   }
   
   
   /**
   * Reads from RAM
   * @param location The address to read from
   * @return The data that was read
   */
	public static String read(int location) 
	{
		if(location >= 0 && location < Driver.RAM_SIZE)
      {
         return ram[location];
      }
      else
      {	
      	System.out.println("RAM Read Error: location-"+location);
         return "";
     	}
	}
	

	/**
	* Writes data to RAM
	* @param data The string to write
	* @param location The address to write the data to
	*/
	public static void write(String data,int location) 
	{
		//System.out.println("Writing:"+data+" to:"+location);	
		if (data != null)
		{		
			data = hexFormat(data);	
			if(location >= 0 && location < Driver.RAM_SIZE)
			{
				ram[location] = data;
			}
			else
			{
				System.out.println ("Write Error");
			}
		}		
		else
			System.out.println ("Invalid");
	}
	
	/**
	* Writes the data to RAM the DMA way
	* @param s The string to be written
	* @param b The base address of this process
	* @param o The offset of this write
	*/
	public static void write(String s, int b, int o) {
		if(s!=null) {
			s=hexFormat(s);
			if(b+o<=0 && b+o<Driver.RAM_SIZE) {
				ram[b+o]=s;
			}
			else {
					System.out.println("RAM Write Error @ Location:"+(b+o));
			}	
		}	
	}	
	
	/**
	* Writes the data to RAM where the page is known
	* @param s The string to be written
	* @param b The page to write to
	* @param o The offset within this page of this write
	* @return The page that was written to
	*/
	public static int write2(String s, int b, int o) {
		if(s!=null) {
			s=hexFormat(s);
///			System.out.println("Writing:"+s+" into:"+b+"+"+o);
			if((b*Driver.WORDS_PER+o)>=0 && (b*Driver.WORDS_PER+o)<Driver.RAM_SIZE) {
				if(isFull[b]==false)
				{
					isFull[b]=true;	
				}
				ram[b*Driver.WORDS_PER+o]=s;
				
			}
			else {
					System.out.println("RAM Write Error @ Location:"+(b+o));
			}	
		}
		return b;	
	}	

	/**
	* Writes the data to RAM where the page is unknown
	* @param s The string to be written
	* @return The page that was written to
	*/
	public int write2(String s) {
		if(s!=null) {
			s=hexFormat(s);
			int b=this.nextFrame();
	//		System.out.println("Writing:"+s+" into:"+b);
			if((b*Driver.WORDS_PER)>=0 && (b*Driver.WORDS_PER)<Driver.RAM_SIZE) {
				if(isFull[b]==false)
				{
					isFull[b]=true;	
				}
				ram[b*Driver.WORDS_PER]=s;
				
			}
			else {
					System.out.println("RAM Write Error @ Location:"+b);
			}
			return (b*Driver.WORDS_PER);	
		}
		return -1;
	}	


}