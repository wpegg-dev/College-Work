#pragma once

class utilites
{
public:
	utilites(void);
	~utilites(void);


	int convertAsciiToNumber(const char &);
};
