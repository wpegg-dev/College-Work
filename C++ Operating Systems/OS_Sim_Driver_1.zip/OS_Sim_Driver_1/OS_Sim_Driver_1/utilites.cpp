
#include "utilites.h"
utilites::utilites(void)
{
}

utilites::~utilites(void)
{
}
